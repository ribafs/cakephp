<?php

namespace Chris48s\Searchable\Exception;

use Cake\Core\Exception\Exception;

class SearchableFatalException extends Exception
{
}
