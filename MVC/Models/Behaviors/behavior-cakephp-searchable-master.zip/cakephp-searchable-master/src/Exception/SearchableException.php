<?php

namespace Chris48s\Searchable\Exception;

use Cake\Core\Exception\Exception;

class SearchableException extends Exception
{
}
