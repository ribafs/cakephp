<?php
	function pointless() {
		return true;
	}
pointless();
?>
