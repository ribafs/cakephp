<?php
use Cake\Core\Plugin;

Plugin::load('Less');
Plugin::load('BootstrapUI');
Plugin::load('Cake/Localized');
