Roteiro para a Criação de um Aplicativo com CakePHP 3 Usando o Componente Control
Para servir de seção de administração

Agora estou mantendo apeas no meu site pessoal:
http://ribafs.org/portal/cakephp/plugins/recursos-extras-default

======================================================
Ribamar FS – http://ribafs.org - Fortaleza, 16/09/2016
