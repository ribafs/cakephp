Plugin for Access Control with CakePHP 3 and default template
=============================================================

[![Licença](https://img.shields.io/packagist/l/doctrine/orm.svg?maxAge=2592000)](https://github.com/ribafs/cake-control-default/blob/master/LICENSE)
[![Último Estável](https://img.shields.io/packagist/v/elboletaire/twbs-cake-plugin.svg?style=flat-square)](https://packagist.org/packages/ribafs/cake-control-default)
[![Tamanho do Download](https://img.shields.io/crates/d/rustc-serialize.svg?maxAge=2592000)](https://github.com/ribafs/cake-control-default/releases)

## Main Resources
    Internacionalization
    Element topmenu
    Layout default
    Editor TinyMCE
    Search with pagination
    Encryption passwords with Bcrypt
    Access Control/Admin/Panel
    Template Bake

# Documentação/Documentation

**Em português**

http://ribafs.org/portal/cakephp/plugins/cake-control-default

http://ribafs.org/portal/cakephp/plugins/recursos-extras-default

http://ribafs.org/portal/cakephp/plugins/internacionalizacao-default


**In english**

http://ribafs.org/portal/cakephp/plugins/cake-control-en-default

http://ribafs.org/portal/cakephp/plugins/extra-resources-default

http://ribafs.org/portal/cakephp/plugins/internationalization-default


# This plugin but with Bootstrap

http://github.com/ribafs/cake-control

Em Português - http://ribafs.org/portal/cakephp/plugins/cake-control

In English - http://ribafs.org/portal/cakephp/plugins/cake-control-en


## Suggestions, collaborations and forks are welcome

- Erros de Português
- Erros de Inglês
- PHP
- CakePHP
- ControlComponent.php
- etc

License
-------

The MIT License (MIT)

