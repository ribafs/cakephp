<?php
use Cake\Core\Plugin;

Plugin::load('Cake/Localized');
