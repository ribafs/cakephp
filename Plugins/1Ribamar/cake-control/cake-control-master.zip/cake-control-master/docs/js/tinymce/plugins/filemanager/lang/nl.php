<?php
define('lang_Select','Selecteren');
define('lang_Erase','Verwijderen');
define('lang_Open','Openen');
define('lang_Confirm_del','Weet u zeker dat u dit bestand wilt verwijderen?');
define('lang_All','Alles');
define('lang_Files','Bestanden');
define('lang_Images','Afbeeldingen');
define('lang_Archives','Archieven');
define('lang_Error_Upload','Het bestand overschrijdt de maximum toegestane grootte.');
define('lang_Error_extension','Bestand extensie is niet toegestaan');
define('lang_Upload_file','Bestand uploaden');
define('lang_Filter','Filter');
define('lang_Videos','Videos');
define('lang_Music','Muziek');
define('lang_New_Folder','Nieuwe map');
define('lang_Folder_Created','Map aangemaakt');
define('lang_Existing_Folder','Bestaande map');
define('lang_Confirm_Folder_del','Weet u zeker dat u naar de map en alle bestanden hierin wilt verwijderen?');
define('lang_Return_Files_List','Terug naar bestanden');
define('lang_Preview','Voorbeeld');
define('lang_Download','Download');
define('lang_Insert_Folder_Name','Map naam:');
define('lang_Root','root');
?>