'use strict';
$(document).ready(function() {

    tinymce.init({
        selector: 'textarea',
        plugins: 'advlist, filemanager, link, media, contextmenu, paste, preview, spellchecker,autoresize,image'
    });






});
