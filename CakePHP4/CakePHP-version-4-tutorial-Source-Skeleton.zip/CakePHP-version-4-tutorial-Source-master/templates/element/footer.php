<footer class="bg-dark mt-3 text-light p-4 text-center">
        footer
    </footer>